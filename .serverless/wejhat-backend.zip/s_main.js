
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'khaldgh',
  applicationName: 'wejhat-backend',
  appUid: 'gmd0fGpBl9xxFhzBLc',
  orgUid: '6e1e3d56-dedb-4886-8cc1-9b6e4ae38ae1',
  deploymentUid: 'ca576281-5702-447a-b440-9d87bffa3532',
  serviceName: 'wejhat-backend',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'wejhat-backend-dev-main', timeout: 6 };

try {
  const userHandler = require('./dist/serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}