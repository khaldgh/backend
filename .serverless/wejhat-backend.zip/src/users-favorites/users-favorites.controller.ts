import { Controller } from '@nestjs/common';

@Controller('users-favorites')
export class UsersFavoritesController {}
